require 'actionmailer_ja'
