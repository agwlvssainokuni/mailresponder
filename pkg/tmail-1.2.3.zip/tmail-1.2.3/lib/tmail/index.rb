#:stopdoc:
# This is here for Rolls. 
# Rolls uses this instead of lib/tmail.rb.

require 'tmail/version'
require 'tmail/mail'
require 'tmail/mailbox'
require 'tmail/core_extensions'
#:startdoc: