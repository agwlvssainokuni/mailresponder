#:stopdoc:
require 'tmail/mailbox'
#:startdoc: